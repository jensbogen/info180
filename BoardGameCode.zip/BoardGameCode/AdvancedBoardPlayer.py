from Board import CROSS, RING
import Board
from BoardComputerPlayer import BoardComputerPlayer

# Modified version of SimpleBoardPlayer
class AdvancedBoardPlayer(BoardComputerPlayer):  

    def __init__(self, the_mark):
        '''
        Constructor
        :param compatibility_score_set:
        '''
        super(AdvancedBoardPlayer, self).__init__(the_mark)
        self.name = "Advanced"

    def evaluate_game_status(self, a_board):
        max_cross_row = 0
        max_ring_row = Board.GAMESIZE-1
        center = Board.GAMESIZE // 2  # Finding the center of the game board
        for i in range(Board.GAMESIZE):
            for j in range(Board.GAMESIZE):
                if a_board.the_grid[i][j] == CROSS:
                    if i > max_cross_row:
                        max_cross_row = i
                if a_board.the_grid[i][j] == RING:
                    if i < max_ring_row:
                        max_ring_row = i

        # Extra points will be given for focusing on center of the game board
        center_control = sum(1 for row in a_board.the_grid if row.count(CROSS) == center // 2) 

        score = 0
        if self.mark == CROSS:
            score = max_cross_row - (Board.GAMESIZE-1-max_ring_row) * center_control  # Where the extra points for moving towards the center of the board is rewarded
        if self.mark == RING:
            score = (Board.GAMESIZE-1-max_ring_row) - max_cross_row
        return score
