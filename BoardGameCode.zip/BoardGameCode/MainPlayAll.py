# Runs all experiments (MAX_DEPTH 5 -> 7 and GAMESIZE 5 -> 7)

from PlayBoardGame import PlayBoardGame
from BoardGameTreeNode import BoardGameTreeNode
from Board import CROSS, RING
import Board

# Reslts
simple_score = 0
advanced_score = 0 

for gamesize in range(5,8):
    Board.GAMESIZE = gamesize  # Select gamesize from Board
    for max_depth in range(5,8):
        BoardGameTreeNode.MAXDEPTH = max_depth # Select max_depth from BoardTreeNode

        # Main.py
        game = PlayBoardGame()

        # allow person to select starter
        game.select_starter()

        # as long as not finished
        while not(game.finished()):
            # brint game board and other information
            game.print_status()

            # allow the player in turn to move, either human or computer
            game.select_move()

        # From PlayBoardGame.py
        if game.status == CROSS and game.player2.mark == CROSS:
            simple_score += 1
        elif game.status == CROSS and game.player1.mark == CROSS:
            advanced_score += 1
        elif game.status == RING and game.player2.mark == RING:
            simple_score += 1
        elif game.status == RING and game.player1.mark == RING:
            advanced_score += 1
        else:
            print("DRAW")

        game.print_result()

        print(f"Advance Score {advanced_score} \nSimple Score: {simple_score}")


