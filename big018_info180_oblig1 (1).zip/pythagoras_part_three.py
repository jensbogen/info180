from heuristic import Heuristic
import math
import make_grid

class PythagorasPartThree(Heuristic):

    @staticmethod
    def h(node):
        x_target = make_grid.SIZE-1
        y_target = make_grid.SIZE-1
        x_difference = abs(x_target - node.i)
        y_difference = abs(y_target - node.j)

        max_difference = max(x_difference, y_difference)

        task_five = 3 * max_difference

        #Task 5
        return task_five




