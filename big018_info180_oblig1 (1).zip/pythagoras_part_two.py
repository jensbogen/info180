from heuristic import Heuristic
import math
import make_grid

class PythagorasPartTwo(Heuristic):

    @staticmethod
    def h(node):
        x_target = make_grid.SIZE-1
        y_target = make_grid.SIZE-1
        x_difference = abs(x_target - node.i)
        y_difference = abs(y_target - node.j)

        euclidean_distance = math.sqrt(x_difference**2 + y_difference**2)

        #Task 4
        return euclidean_distance




